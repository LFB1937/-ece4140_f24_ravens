/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "picoedub.h"

/*
//UNCOMMENT THIS BLOCK FOR 50 MHZ
#define CLOCK_FREQ  50
#define POST_DIV_1  5
#define POST_DIV_2  3
#define VCOUT       750   
*/

//UNCOMMENT THIS BLOCK FOR 80 MHZ
#define CLOCK_FREQ  80
#define POST_DIV_1  5
#define POST_DIV_2  3
#define VCOUT       1200   



//variables for timer and alarm
int8_t i8_alarmNum = 0;
uint32_t u32_expireTime;
uint32_t u32_refTime = 0;
bool b_resetAlarm = false;
uint32_t u32_time2Expire= 1000;


//circular buffers
circular_buffer  cb_inputBuffer;
circular_buffer *pcb_inputBuffer = &cb_inputBuffer;
circular_buffer  cb_outputBuffer;
circular_buffer *pcb_outputBuffer = &cb_outputBuffer;
bool b_toggle = false;
uint8_t u8_buf = 0;
uint8_t *pu8_buf = &u8_buf;
uint8_t u8_callbackBuf = 0;
uint8_t *pu8_callbackBuf = &u8_callbackBuf;

void alarmCallback(){
    if(!b_toggle){
        pico_set_led(true);
        b_toggle = 1;
    } else if(b_toggle){
        //gpio_put(PICOEDUB_LED3_PIN, false);
        pico_set_led(false);
        b_toggle = 0;
    }  
    u32_refTime = time_us_32();  
    hardware_alarm_set_target(i8_alarmNum, u32_refTime + u32_time2Expire);
    watchdog_update();     
}

void uartCallback(){
    if(uart_is_readable(UART_ID)){
        
        u8_callbackBuf = uart_getc(UART_ID);
        cb_push_back(pcb_inputBuffer, pu8_callbackBuf);   
    } 
    if(uart_is_writable(UART_ID)){
        if(!cb_isEmpty(pcb_outputBuffer)){
            //test led
            gpio_put(PICOEDUB_LED2_PIN, true);
            cb_pop_front(pcb_outputBuffer, pu8_callbackBuf);
            uart_putc(UART_ID, *pu8_callbackBuf);
        }
        else{
            uart_set_irqs_enabled(UART_ID, true, false);
            //this disables the TX interrupt. This is here to prevent unnessesary calls to this function

        }
        
    }
    uart0_hw->icr |= (11111111111);
}


//initializations needed for this program
void edub_init(){

    stdio_init_all();
    pico_led_init();
    //gpio_to_EDUB_led_init(PICOEDUB_LED0_PIN);
    //gpio_to_EDUB_led_init(PICOEDUB_LED1_PIN);
    gpio_to_EDUB_led_init(PICOEDUB_LED2_PIN);
    gpio_to_EDUB_led_init(PICOEDUB_LED3_PIN);

    //init pico2 to specified MHZ
    //in order to change the pll_sys, we need to change the clock 
    //to the reference clock (@ 12 MHZ) so it doesnt shut down the system when configuring pll
    
    clock_configure(clk_sys,
                CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLK_REF,
                0,
                12 * MHZ,
                12 * MHZ
    );

    //can now change the system pll
    pll_init(pll_sys, 1, VCOUT * MHZ, POST_DIV_1, POST_DIV_2);

    //set clock to the reinitialzed sys_pll
    clock_configure(clk_sys,
                CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,
                CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,
                CLOCK_FREQ * MHZ,
                CLOCK_FREQ * MHZ
    );
    

    clock_configure(clk_peri,
                CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,
                CLOCKS_CLK_PERI_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,
                CLOCK_FREQ * MHZ,
                CLOCK_FREQ * MHZ
    );
    //reinit uart now that peripherial frequency is high enough
    stdio_init_all();

    //initialze circular buffers
    cb_init(pcb_outputBuffer);
    cb_init(pcb_inputBuffer);

    //UART init*********************************************************
    // Set up our UART with a basic baud rate.
    uart_init(UART_ID, 2400);

    // Set the TX and RX pins by using the function select on the GPIO
    // Set datasheet for more information on function select    
    gpio_set_function(UART_TX_PIN, UART_FUNCSEL_NUM(UART_ID, UART_TX_PIN));
    gpio_set_function(UART_RX_PIN, UART_FUNCSEL_NUM(UART_ID, UART_RX_PIN));

    // Actually, we want a different speed
    // The call will return the actual baud rate selected, which will be as close as
    // possible to that requested    
    uint32_t u32_baud_actual = uart_set_baudrate(UART_ID, BAUD_RATE);

    // Set UART flow control CTS/RTS, we don't want these, so turn them off
    uart_set_hw_flow(UART_ID, false, false);
    uart_set_fifo_enabled (UART_ID, false);
    // Set our data format
    uart_set_format(UART_ID, DATA_BITS, STOP_BITS, PARITY);
    //uart_set_fifo_enabled(UART_ID, false);
    //End UART init*****************************************************

    //set up sw 5
    gpio_init(PICOEDUB_SW5_PIN);
    gpio_set_dir(PICOEDUB_SW5_PIN, GPIO_IN);
    gpio_pull_down(PICOEDUB_SW5_PIN);

    //SET UP TIMER 
    //will not panic with false
    i8_alarmNum = hardware_alarm_claim_unused(false);
    u32_time2Expire = 1000;
    hardware_alarm_set_callback(i8_alarmNum, &alarmCallback);
    

    //Turn on all interrupts nedded
         
    //static void uart_set_irqs_enabled (uart_inst_t * uart, bool rx_has_data, bool tx_needs_data)
    irq_set_exclusive_handler (UART0_IRQ, uartCallback);
    irq_set_enabled(UART0_IRQ, true);
    u32_refTime = time_us_32();
    hardware_alarm_set_target(i8_alarmNum, u32_refTime + u32_time2Expire);
    //These flags will be used in IRQ to know what needs to be serviced
    uart_set_irqs_enabled(UART_ID, true, false);

}


uint32_t tenPowerNum(uint8_t power){
    uint32_t num = 1;
    for(uint8_t i = 0; i < power; i++){
        num = num * 10;
    }
    return num;
}

int main() {
    edub_init();
    if (watchdog_caused_reboot()) {
        gpio_put(PICOEDUB_LED3_PIN, true);
        //
        
    } else {
        //printf("Clean boot\n");
    }
    
    // Enable the watchdog, requiring the watchdog to be updated every 100ms or the chip will reboot
    // second arg is pause on debug which means the watchdog will pause when stepping through code
    watchdog_enable(1000, 1);
    
    //making this the 'on' light for now
    //this putc is required because the TX interrupt will not work
    //without an initial putc
    uart_putc(UART_ID, '1');
    //uart0_hw->icr |= (11111111111);

    while (true) {
        
    }
}
